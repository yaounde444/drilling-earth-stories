import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

export type Language = "fr" | "en";

type LanguageContextValue = {
  language: Language;
  setLanguage: (language: Language) => void;
  choose: <T,>(content: { fr: T; en: T }) => T;
};

const translations: Record<string, string> = {
  "Home": "Accueil", "Services": "Services", "Equipment": "Équipements", "Projects": "Réalisations", "About": "À propos", "About us": "À propos de nous", "Contact": "Contact",
  "The company": "L’entreprise", "Company": "Entreprise", "Capability": "Compétences", "Method": "Méthode", "From the field": "Sur le terrain", "Track record": "Références", "Field archive": "Archives terrain", "Support plant": "Équipements de soutien", "Fleet": "Flotte", "Crew": "Équipe", "Setup": "Installation", "Test": "Essai", "Stage": "Étape", "Outcome": "Résultat", "Formation": "Formation", "Configuration": "Configuration", "Access": "Accès", "Diameters": "Diamètres", "Depth capacity": "Capacité de profondeur", "Typical use": "Utilisation habituelle", "Typical drilling depth": "Profondeur de forage habituelle", "Mobilisation window": "Délai de mobilisation", "Site hours": "Horaires d’intervention", "Telephone": "Téléphone", "Email": "E-mail", "Base": "Base", "Full name": "Nom complet", "Site location / town": "Lieu du site / ville", "Service required": "Service demandé", "Project details": "Détails du projet",
  "Request a quotation": "Demander un devis", "Request a site visit": "Demander une visite du site", "Request a borehole drilling quotation or a site visit from Pacific Forage SARL, Yaoundé, Cameroon.": "Demandez un devis de forage ou une visite de site à Pacific Forage SARL, Yaoundé, Cameroun.", "Demander un devis": "Demander un devis", "Call the drilling desk": "Appeler le service forage", "Appeler le service forage": "Appeler le service forage", "Contact the drilling desk": "Contacter le service forage", "Start a project": "Démarrer un projet", "Talk to us": "Parlez-nous", "See the rig fleet": "Voir la flotte de foreuses", "Fleet & specifications": "Flotte et spécifications", "View all projects": "Voir tous les projets", "Send another enquiry": "Envoyer une autre demande",
  "Rotary & DTH Drilling": "Forage rotary et DTH", "Borehole Drilling": "Forage de puits", "Borehole Development": "Développement de forage", "Pump Testing": "Essai de pompage", "Pump Installation": "Installation de pompe", "Hydrogeological Survey": "Étude hydrogéologique", "Rapid Mobilisation": "Mobilisation rapide", "Borehole rehabilitation": "Réhabilitation de forage", "Borehole Rehabilitation": "Réhabilitation de forage", "Pump installation": "Installation de pompe", "Pump testing": "Essai de pompage", "Hydrogeological survey": "Étude hydrogéologique", "Borehole development": "Développement de forage", "Borehole drilling": "Forage de puits",
  "Water is found before it is drilled.": "L’eau se trouve avant d’être forée.", "Rotary and down-the-hole, to whatever the formation demands.": "Forage rotary et fond de trou, selon les exigences de la formation.", "The hole is not finished until the water runs clear.": "Le forage n’est terminé que lorsque l’eau est claire.", "Commissioned systems, not delivered boxes.": "Des systèmes mis en service, pas des équipements simplement livrés.", "Bringing failed boreholes back into service.": "Remettre en service les forages défaillants.", "Everything between the survey peg and the running tap": "Tout ce qui relie le point d’étude au robinet en service",
  "One contractor, the full water chain": "Un seul prestataire pour toute la chaîne de l’eau", "Survey, drilling, casing and screening, development, testing, pumping and reticulation. Nothing is sub-let to a broker, so nothing gets lost between trades.": "Étude, forage, tubage et crépinage, développement, essais, pompage et distribution. Rien n’est sous-traité à un intermédiaire : la continuité du projet est assurée.",
  "Owned, not hired": "Propriétaire, pas loué", "Our iron is on our own plates": "Nos équipements nous appartiennent", "Owned iron, maintained in house": "Équipements en propre, entretenus en interne", "Own the whole chain": "Maîtriser toute la chaîne", "Evidence before iron": "Les données avant la foreuse", "Complete to standard": "Achever selon les normes", "Safety on the rig floor": "La sécurité sur la foreuse", "Maintain relentlessly": "Entretenir sans relâche", "Leave the site clean": "Laisser un chantier propre",
  "Site & survey": "Site et étude", "Drill & case": "Forer et tuber", "Develop & test": "Développer et tester", "Equip & hand over": "Équiper et remettre",
  "Real sites. Real water.": "Des sites réels. De l’eau réelle.", "Tell us where you need water": "Dites-nous où vous avez besoin d’eau", "Your site could be the next one": "Votre site pourrait être le prochain",
  "Sites we have drilled, developed and equipped": "Sites que nous avons forés, développés et équipés", "Photographs from our sites": "Photographies de nos sites",
  "Residential development": "Développement résidentiel", "Community water": "Eau communautaire", "Urban compound": "Enceinte urbaine", "Agriculture": "Agriculture", "Hillside estate supply borehole": "Forage d’alimentation d’un domaine en pente", "High-yield community borehole": "Forage communautaire à haut rendement", "Residential compound borehole": "Forage pour enceinte résidentielle", "Irrigation borehole, lateritic terrain": "Forage d’irrigation en terrain latéritique", "Estate supply in service": "Alimentation du domaine en service", "Sustained community yield": "Débit communautaire durable", "Private supply commissioned": "Alimentation privée mise en service", "Irrigation supply": "Alimentation pour irrigation", "Constrained terrace": "Terrasse à accès contraint", "Tight urban plot": "Terrain urbain exigu", "Laterite over basement": "Latérite sur socle rocheux", "Step + constant rate": "Essai par paliers + débit constant", "DTH hammer": "Marteau DTH", "Air rotary": "Rotary à l’air", "Air rotary and DTH": "Rotary à l’air et DTH",
  "Truck-mounted rotary rig — primary unit": "Foreuse rotary sur camion — unité principale", "Truck-mounted rotary rig — second unit": "Foreuse rotary sur camion — deuxième unité", "Compact access rig": "Foreuse compacte pour accès difficiles", "Support fleet": "Flotte de soutien", "Downhole tooling": "Outillage de fond de trou",
  "Monday – Saturday, 07:00 – 18:00": "Lundi – samedi, 07:00 – 18:00", "Yaoundé, Cameroon": "Yaoundé, Cameroun",
  "1 200+": "1 200+", "Boreholes completed": "Forages réalisés", "150 m+": "150 m+", "10": "10", "24 h": "24 h",
  "Water is life. We reach it.": "L’eau, c’est la vie. Nous l’atteignons.", "L’eau, c’est la vie. Nous l’atteignons.": "L’eau, c’est la vie. Nous l’atteignons.",
  "A drilling contractor built around finishing the hole": "Un prestataire de forage conçu pour aller jusqu’au bout", "Who we are": "Qui sommes-nous", "How we work": "Notre façon de travailler", "Drillers, not day labour": "Des foreurs, pas de simples journaliers", "Work with the crew that finishes": "Travaillez avec l’équipe qui va jusqu’au bout",
  "Pacific Forage SARL was founded to do one thing properly: put reliable, tested, well-constructed boreholes into ground that other contractors walk away from.": "Pacific Forage SARL a été créée pour faire une chose correctement : réaliser des forages fiables, testés et bien construits, même dans les terrains où d’autres prestataires abandonnent.",
  "A Cameroonian drilling contractor with owned plant, trained crews and an in-house standard for completing every hole.": "Un prestataire camerounais disposant de ses propres équipements, d’équipes formées et d’un standard interne pour achever chaque forage.",
  "Drilling Services — Pacific Forage SARL": "Services de forage — Pacific Forage SARL", "Rig Fleet & Equipment — Pacific Forage SARL": "Flotte de foreuses et équipements — Pacific Forage SARL", "Projects & Field Record — Pacific Forage SARL": "Réalisations et références terrain — Pacific Forage SARL", "Contact & Quotations — Pacific Forage SARL": "Contact et devis — Pacific Forage SARL",
  "The company": "L’entreprise", "Principles": "Principes", "The crew": "L’équipe",
  "Request a quotation": "Demander un devis", "Tell us where you need water": "Dites-nous où vous avez besoin d’eau",
  "Intended use, daily demand, access conditions, timing…": "Usage prévu, demande quotidienne, conditions d’accès, calendrier…", "Borehole drilling": "Forage de puits", "Hydrogeological survey": "Étude hydrogéologique", "Pump installation": "Installation de pompe", "Pump testing": "Essai de pompage", "Borehole development": "Développement de forage", "Borehole rehabilitation": "Réhabilitation de forage",
  "For an accurate quotation, include the plot location (or GPS coordinates), what the water is for, and roughly how many cubic metres per day you need.": "Pour un devis précis, indiquez l’emplacement du terrain (ou ses coordonnées GPS), l’usage de l’eau et le volume approximatif nécessaire par jour.",
  "Enquiry ready to send": "Demande prête à être envoyée", "Thank you. Your details have been captured on this page. To reach the drilling desk immediately, call": "Merci. Vos informations ont été enregistrées sur cette page. Pour joindre immédiatement le service forage, appelez", "or email": "ou écrivez à",
  "Full casing, screening and gravel-pack inventory carried to site": "Tout le matériel de tubage, crépinage et massif filtrant est acheminé sur site", "Crews in PPE, supervised by a qualified driller on every shift": "Équipes en EPI, supervisées par un foreur qualifié à chaque poste", "Truck-mounted rotary rigs with onboard mast and rod handling": "Foreuses rotary sur camion avec mât et manutention des tiges intégrés", "High-pressure compressors for DTH hammer work in hard basement": "Compresseurs haute pression pour le marteau DTH dans les socles rocheux durs",
  "Water bowser, materials truck and crew transport keep the rig drilling instead of waiting on deliveries.": "La citerne à eau, le camion de matériaux et le transport de l’équipe permettent à la foreuse de continuer à travailler sans attendre les livraisons.",
  "Hammers, bits, stabilisers, drill collars and fishing tools carried to site so a stuck string never becomes a lost hole.": "Marteaux, taillants, stabilisateurs, masses-tiges et outils de repêchage sont acheminés sur site afin qu’une colonne bloquée ne devienne jamais un forage perdu.",
  "Submersible and solar pumping systems, rising mains, control gear, tanks and reticulation — commissioned and handed over.": "Systèmes de pompage submersibles et solaires, conduites de refoulement, équipements de commande, réservoirs et réseau — installés, mis en service et remis au client.",
  "Submersible and solar pumping systems are sized to the tested yield and the real head, then installed with rising main, cable, control gear, headworks, storage and distribution. The site is handed over running, with the operator shown how to run it.": "Les systèmes de pompage submersibles et solaires sont dimensionnés selon le débit testé et la hauteur manométrique réelle, puis installés avec conduite de refoulement, câble, commande, tête de forage, stockage et distribution. Le site est remis en service avec formation de l’opérateur.",
  "Step-drawdown and constant-rate tests with recovery monitoring, sized to the aquifer rather than to the pump catalogue.": "Essais par paliers et à débit constant avec suivi de la remontée, dimensionnés selon l’aquifère et non selon un catalogue de pompes.",
  "Airlift and surge development until the column runs clean and the aquifer delivers its designed yield.": "Développement par airlift et surging jusqu’à obtenir une eau claire et le débit prévu de l’aquifère.",
  "Electrical resistivity and VES siting before a single metre is drilled, so the rig lands on water, not on hope.": "Étude de résistivité électrique et VES avant de forer le moindre mètre, afin de positionner la foreuse sur une cible hydrogéologique plutôt que sur une hypothèse.",
  "Self-contained rigs with onboard compressors, support truck, water bowser and crew — no third-party hire, no waiting.": "Foreuses autonomes avec compresseurs intégrés, camion de soutien, citerne à eau et équipe — sans location auprès de tiers ni attente.",
  "Send the location, the intended use and the daily demand. We reply with a survey plan, a drilling programme and a price.": "Envoyez l’emplacement, l’usage prévu et la demande quotidienne. Nous vous répondons avec un plan d’étude, un programme de forage et un prix.",
  "Send the location and the demand. We come back with a survey plan, a drilling programme and a fixed price.": "Envoyez l’emplacement et le besoin. Nous vous répondons avec un plan d’étude, un programme de forage et un prix ferme.",
};

function normalise(value: string) {
  return value.replace(/\s+/g, " ").trim();
}

const originalText = new WeakMap<Text, string>();
let translating = false;

function translateDom(language: Language) {
  if (typeof document === "undefined" || translating) return;
  translating = true;
  const root = document.body;
  if (!root) return;

  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  const nodes: Text[] = [];
  let node: Node | null;
  while ((node = walker.nextNode())) nodes.push(node as Text);

  for (const text of nodes) {
    const parent = text.parentElement;
    if (!parent || ["SCRIPT", "STYLE", "NOSCRIPT"].includes(parent.tagName)) continue;
    if (!text.nodeValue?.trim()) continue;
    const original = originalText.get(text) ?? text.nodeValue;
    originalText.set(text, original);
    if (language === "en") {
      text.nodeValue = original;
      continue;
    }
    const key = normalise(original);
    const match = translations[key];
    if (match) {
      const leading = original.match(/^\s*/)?.[0] ?? "";
      const trailing = original.match(/\s*$/)?.[0] ?? "";
      text.nodeValue = leading + match + trailing;
    }
  }

  const attrs = ["alt", "placeholder", "aria-label", "title"];
  document.querySelectorAll<HTMLElement>("*").forEach((el) => {
    for (const attr of attrs) {
      const value = el.getAttribute(attr);
      if (!value) continue;
      const originalKey = `data-pf-original-${attr}`;
      const original = el.getAttribute(originalKey) ?? value;
      el.setAttribute(originalKey, original);
      if (language === "en") el.setAttribute(attr, original);
      else el.setAttribute(attr, translations[normalise(original)] ?? original);
    }
  });
  translating = false;
}

const LanguageContext = createContext<LanguageContextValue | null>(null);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>("fr");

  useEffect(() => {
    const saved = window.localStorage.getItem("pacific-forage-language");
    if (saved === "en" || saved === "fr") setLanguageState(saved);
  }, []);

  useEffect(() => {
    document.documentElement.lang = language;
    const run = () => translateDom(language);
    run();
    const observer = new MutationObserver(run);
    observer.observe(document.body, { childList: true, subtree: true, characterData: true });
    return () => observer.disconnect();
  }, [language]);

  const value = useMemo<LanguageContextValue>(() => ({
    language,
    setLanguage: (next) => {
      setLanguageState(next);
      window.localStorage.setItem("pacific-forage-language", next);
    },
    choose: (content) => content[language],
  }), [language]);

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) throw new Error("useLanguage must be used within LanguageProvider");
  return context;
}
